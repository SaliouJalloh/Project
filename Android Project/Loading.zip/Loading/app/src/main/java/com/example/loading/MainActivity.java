package com.example.loading;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

public class MainActivity extends AppCompatActivity {

    private TextView text,size;
    private Button reset, loading, save;
    private ImageView img;
    private Bitmap bitmap;
    private Bitmap image;
    private int width, height, tmp_color;

    private  String photoPath = null;

    // Constantes
    private static final int REQUEST_TAKE_PHOTO = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initActivity();

    }

    private void initActivity() {
        // instanciation

        img = findViewById(R.id.idimage);

        loading = findViewById(R.id.idload);
        save = findViewById(R.id.idsave);

        // Convertion de l'image

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inMutable = true;

        //initialisation des bitmap
        bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.fruit,options);

        createOnClickButton();

    }

    private void createOnClickButton(){

        loading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Accès a la camera
                prendreUnePhoto();

            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save image
                MediaStore.Images.Media.insertImage(getContentResolver(),image,"nom image","description");


            }
        });

    }

    private void prendreUnePhoto() {
        // creer un intent pour ouvrir une fenetre pour prendre une photo
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // test pour
        if(intent.resolveActivity(getPackageManager()) != null){
            // creer un new fichier
            String time = new SimpleDateFormat("yyyyMMMdd_HHmmss").format(new Date());
            File photoDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            try {
                File photoFile = File.createTempFile("photo"+time,".jpg",photoDir);
                // Enregistrer le chemin complet
                photoPath = photoFile.getAbsolutePath();
                // creer l'Uri
                Uri photoUri = FileProvider.getUriForFile(MainActivity.this,
                        MainActivity.this.getApplicationContext().getPackageName()+ ".provider",photoFile);
                //
                intent.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
                //
                startActivityForResult(intent,REQUEST_TAKE_PHOTO);

            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK){
            //recupere l'image
            image = BitmapFactory.decodeFile(photoPath);
            //afficher l'image
            img.setImageBitmap(image);
        }

    }

}
